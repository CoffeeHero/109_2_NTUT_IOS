//
//  Homework09V2App.swift
//  Homework09V2
//
//  Created by  iLab on 2021/5/26.
//

import SwiftUI

@main
struct Homework09V2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
