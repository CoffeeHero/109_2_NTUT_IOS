//
//  ContentView.swift
//  Homework09V2
//
//  Created by  iLab on 2021/5/26.
//

import SwiftUI

struct ContentView: View {
    @StateObject var gameViewModel = GameViewModel()
    var body: some View {
        VStack {
            Text("猜拳遊戲").font(.largeTitle)
            HStack{
                Text("玩家: ")
                Text(gameViewModel.player?.kind.rawValue ?? "👊石頭")
                
            } .font(.system(size: 30))
            HStack{
                Text("電腦: ")
                Text(gameViewModel.computer?.kind.rawValue ?? "👊石頭")
            } .font(.system(size: 30))
            if let result = gameViewModel.result {
                if (result == .win){
                    Text("玩家獲勝")
                        .font(.system(size: 30))
                }
                else if (result == .lose){
                    Text("玩家敗北")
                        .font(.system(size: 30))
                }
                else{
                    Text("平手")
                        .font(.system(size: 30))
                }
            }
            Button(action: {
                gameViewModel.play()
            }, label: {
                Text("出拳！")
            }).font(.system(size: 30))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

