//
//  GameViewModel.swift
//  Homework09V2
//
//  Created by  iLab on 2021/5/26.
//

import Foundation
import GameplayKit

class GameViewModel: ObservableObject {
    @Published var player: Fist?
    @Published var computer: Fist?
    @Published var result: GameResult?
    
    var varc: [Fist] = {
        var fist = [Fist]()
        for kind in Fist.Kind.allCases {
            let finger = Fist(kind: kind)
            fist.append(finger)
        }
        return fist
    }()
    
    
    
    func fight() ->  GameResult {
        if player?.kind.rawValue == "👊石頭" {
            if computer?.kind.rawValue == "👊石頭"{
                return .tie
            }
            else if computer?.kind.rawValue == "🖐布"{
                return .lose
            }
            else if computer?.kind.rawValue == "✌️剪刀"{
                return .win
            }
            
        }
        else if player?.kind.rawValue == "🖐布" {
            if computer?.kind.rawValue == "🖐布"{
                return .tie
            }
            else if computer?.kind.rawValue == "✌️剪刀"{
                return .lose
            }
            else if computer?.kind.rawValue == "👊石頭"{
                return .win
            }
            
        }
        else if player?.kind.rawValue == "✌️剪刀" {
            if computer?.kind.rawValue == "👊石頭"{
                return .lose
            }
            else if computer?.kind.rawValue == "🖐布"{
                return .win
            }
            else if computer?.kind.rawValue == "✌️剪刀"{
                return .tie
            }
        }
        return .nothing
    }
    func play() {
//        fingers.shuffle()
        let number1 = Int.random(in: 0...2)
        let number2 = Int.random(in: 0...2)
        player = varc[number1]
        computer = varc[number2]
        result = fight()
    }
}
