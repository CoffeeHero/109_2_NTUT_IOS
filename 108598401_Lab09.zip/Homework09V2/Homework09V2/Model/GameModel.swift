//
//  GameModel.swift
//  Homework09V2
//
//  Created by  iLab on 2021/5/26.
//

import Foundation
enum GameResult {
    case win
    case lose
    case tie
    case nothing
}
struct Fist {
    let kind: Kind
    
    enum Kind: String, CaseIterable {
        case rock = "👊石頭"
        case paper = "🖐布"
        case scissors = "✌️剪刀"
    }
    
}
