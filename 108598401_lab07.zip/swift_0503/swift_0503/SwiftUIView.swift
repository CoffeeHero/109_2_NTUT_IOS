//
//  SwiftUIView.swift
//  swift_0503
//
//  Created by  iLab on 2021/5/12.
//

import SwiftUI

let introduction = ["《復仇者聯盟：終局之戰》（英語：Avengers: Endgame）是一部於2019年上映的美國史詩超級英雄電影","由漫威影業製作及華特迪士尼工作室電影發行。", "此電影由羅素兄弟執導，及由史蒂芬·麥費利與克里斯多佛·馬庫斯負責撰寫劇本。"]

struct SwiftUIView: View {
    var body: some View {
//        Text("Introduction")
//            .navigationTitle("Hello! A")
        VStack{
            ForEach (0..<introduction.count){ index in
                Text(introduction[index])
            }
        }.navigationTitle("Introduction")
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            SwiftUIView()
        }
    }
}
