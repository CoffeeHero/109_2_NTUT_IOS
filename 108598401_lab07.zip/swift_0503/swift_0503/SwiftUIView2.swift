//
//  SwiftUIView2.swift
//  swift_0503
//
//  Created by  iLab on 2021/5/12.
//

import SwiftUI
let actor = ["小勞勃·道尼","克里斯·伊凡", "克里斯·漢斯沃", "馬克·盧法洛", "史嘉蕾·喬韓森"]
struct SwiftUIView2: View {
    var body: some View {
        VStack{
            ForEach (0..<actor.count){ index in
                Text(actor[index])
            }
        }.navigationTitle("actor")
    }
}

struct SwiftUIView2_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            SwiftUIView2()
        }
    }
}
