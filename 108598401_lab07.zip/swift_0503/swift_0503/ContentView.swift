//
//  ContentView.swift
//  swift_0503
//
//  Created by  iLab on 2021/5/3.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack{
//                Text("Avergers: Endgame")
//                    .multilineTextAlignment(.center)
//                    .padding()
//                Spacer()
                Image("poster")
                    .resizable()
                NavigationLink(
                    
                    destination: SwiftUIView(),
                    label: {
                        Text("Introduction")
                    }
                )
                NavigationLink(
                    
                    destination: SwiftUIView2(),
                    label: {
                        Text("Actors")
                    }
                )
            }
            . navigationTitle("Avengers: Endgame")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
