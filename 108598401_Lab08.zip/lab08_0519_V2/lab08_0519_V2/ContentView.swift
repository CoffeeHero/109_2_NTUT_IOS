//
//  ContentView.swift
//  lab08_0519_V2
//
//  Created by  iLab on 2021/5/19.
//

import SwiftUI

import SwiftUI
struct ContentView: View {
    var roles = ["0", "1", "2", "3"]
    @State private var selectedIndex = 0
    @State private var word = ""
    @State private var anger = false
    @State private var birthday = Date()
    @State private var weight: CGFloat = 1
    @State var friendValue: Int = 0
    @State private var showAlert = false
    var body: some View {
        VStack {
            Text("可愛的貓咪")
            
            Image("cat2")
                .resizable()
                .scaledToFit()
            
            Toggle("愛生氣", isOn: $anger)
            
            DatePicker("生日", selection: $birthday)
            
            Stepper("朋友數量: \(friendValue)", value: $friendValue)
                    
            
            Text("體重")
            Slider(value: $weight, in: 0...150)

//            Text("體重")
            Picker(selection: $selectedIndex, label: Text("我愛吃")) {
                
                
                ForEach(roles.indices) { (index) in
                    Text(roles[index])
                }
            }
            
            TextField("說些什麼", text: $word)
            
            
            Button(action: {
                showAlert = true
                   }) {
                       Text("Submit")
                           .font(.system(size: 40))
                           .background(Color.white)
                           .foregroundColor(.black)
                   }
               
        }.alert(isPresented: $showAlert) { () -> Alert in
            let answer = "愛生氣: \(anger)\n生日: \(birthday)\n朋友數量: \(friendValue)\n體重: \(weight)\n編號: \(selectedIndex)\n說些什麼: \(word)"
            return Alert(title: Text(answer))}
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
